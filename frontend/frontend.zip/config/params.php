<?php
return [
    'adminEmail' => 'no.reply@skyhint.com',
    'bsVersion' => '5.x',
	
];
